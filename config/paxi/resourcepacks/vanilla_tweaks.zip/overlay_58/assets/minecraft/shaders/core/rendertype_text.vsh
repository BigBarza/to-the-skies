#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

bool isgui(mat4 ProjMat) {
    return ProjMat[2][3] == 0.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    // this is to prevent gui text looking weird at night
    vec4 lightColour = isgui(ProjMat) ? texelFetch(Sampler2, UV2 / 16, 0) : minecraft_sample_lightmap(Sampler2, UV2);
    vertexColor = Color * lightColour;

    texCoord0 = UV0;
}
