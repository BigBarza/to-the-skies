gamerule reducedDebugInfo false
tellraw @a ["[No F3] Please delete the datapack or mod now."]
datapack disable "file/No F3 V4"
datapack disable "file/No F3 V4.zip"